
from django.urls import path
from .import views

urlpatterns = [
    path('', views.home),
    path('starthere', views.starthere),
    path('about', views.about),

    # registration path
    path('user/register_user', views.register_user),
    path('user/login', views.login),
    
    # dashboard path
    path('groups_dashboard', views.groups_dashboard),

    # org a new group
    path('groups/new', views.addagroup),
    path('groups/create', views.groups_new),

    # Editing a book group
    path('groups/edit/<int:group_id>', views.editgroup),
    path('groups/updatedgroup/<int:group_id>', views.updategroup),

    # Removing a book group
    path('groups/remove/<int:group_id>', views.removegroup),

    # Joining a book group
    path('groups/join/<int:group_id>', views.join),

    # Leave a book group
    path('groups/cancel/<int:group_id>', views.leave),
    
    # book group detail page and commentary
    path('groups/detail/<int:group_id>', views.grouppage),

    # Create comment
    path('groups/createcomment/<int:group_id>', views.createcomment),

    path('logout', views.logout)
]

