from django.shortcuts import render, redirect
from .models import User, BookGroup, Comment
from django.contrib import messages
import bcrypt

def home(request):
    return render(request, "home.html")

def starthere(request):
    return render(request, "starthere.html")

def about(request):
    return render(request, "about.html")


# registration page  - Groups.html
def register_user(request):
    if request.method == "POST":

        errors = User.objects.validator(request.POST)

        if len(errors) > 0:
            for key,value in errors.items():
                messages.error(request, value)
            return redirect('/starthere')

        hash_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        print(hash_pw)
        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = hash_pw
        )
        request.session['logged_user'] = new_user.id

        return redirect('/groups_dashboard') 
    return redirect("/starthere")

def login(request):
    print(request.method)
    if request.method == "POST":
        user = User.objects.filter(email = request.POST['email'])

        if user:
            log_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(), log_user.password.encode()):
                request.session['logged_user'] = log_user.id
                return redirect('/groups_dashboard') 
        messages.error(request, "Email or password are incorrect.")
    return redirect("/starthere")

def groups_dashboard(request):
    if 'logged_user' not in request.session:

        messages.error(request, "Please login to view your dashboard")
        return redirect('/starthere')

    context = {
        'logged_user' : User.objects.get(id=request.session['logged_user']),
        'all_groups' : BookGroup.objects.all()
    }

    return render(request, "dashboard.html", context)

def addagroup(request):
    context = {
        'logged_user': User.objects.get(id=request.session['logged_user']),
    }
    return render (request, "add.html", context)


def groups_new(request):
    if request.method == "POST":
        user = User.objects.get(id=request.session['logged_user'])
        new_book = BookGroup.objects.create(
            book_name = request.POST['book_name'],
            book_author = request.POST['book_author'],
            book_year = request.POST['book_year'],
            book_group_creator = user
            )
        new_book.book_group_members.add(user)

        return redirect('/groups_dashboard')

# editing
def editgroup(request, group_id):
    context = {
        'logged_user' : User.objects.get(id=request.session['logged_user']),
        'this_group' : BookGroup.objects.get(id=group_id)
    }
    return render(request, "edit.html", context)

def updategroup(request, group_id):
    if 'logged_user' not in request.session:
            messages.error(request, "Please register or login")
            return redirect('/starthere')

    group_to_update = BookGroup.objects.get(id=group_id)
    group_to_update.book_name = request.POST['book_name']
    group_to_update.book_author = request.POST['book_author']
    group_to_update.book_year = request.POST['book_year']
    group_to_update.save()
    return redirect('/groups_dashboard')

def removegroup(request, group_id):
    BookGroup.objects.get(id=group_id).delete()
    return redirect('/groups_dashboard')

def join(request, group_id):
    logged_user = User.objects.get(id=request.session['logged_user'])
    group_to_join = BookGroup.objects.get(id=group_id)
    group_to_join.book_group_members.add(logged_user) 
    group_to_join.save()
    return redirect('/groups_dashboard')

def leave(request, group_id):
    logged_user = User.objects.get(id=request.session['logged_user'])
    group_to_leave = BookGroup.objects.get(id=group_id)
    group_to_leave.book_group_members.remove(logged_user) 
    group_to_leave.save()
    return redirect('/groups_dashboard')

def grouppage(request, group_id):
    context3 = {
        'logged_user' : User.objects.get(id=request.session['logged_user']),
        'this_group' : BookGroup.objects.get(id=group_id)
    }
    return render(request, "bookgrouppage.html", context3)

def createcomment(request, group_id):
    if request.method == "POST":
        user = User.objects.get(id=request.session['logged_user'])
        new_comment = Comment.objects.create(
            comment_content = request.POST['comment_content'],
            which_book = BookGroup.objects.get(id=group_id),
            commentator = user         
            )
        return redirect('/groups/detail/' + str(group_id))

def logout(request):
    request.session.flush()
    return redirect('/')

