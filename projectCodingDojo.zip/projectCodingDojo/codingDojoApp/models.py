from django.db import models
import re
from datetime import datetime
import bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 4:
            errors['first_name'] = "First name must be at least 4 characters"

        if len(postData['last_name']) < 4:
            errors['last_name'] = "Last name must be at least 4 characters"

        if not EMAIL_REGEX.match(postData['email']):   
            errors['email'] = "This is invalid email address. Please try again."

        users_with_email = User.objects.filter(email = postData['email'])
        if len(users_with_email) >= 1:
            errors['duplicate'] = "Email already exists."

        if len(postData['password']) < 4:
            errors['password'] = "Password must be at least 4 characters. Please try again."

        if postData['password'] != postData['confirm_password']:
            errors['pw_match'] = "Your passwords must match. Please try again."

        return errors
      
class User(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=45)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
    # book_groups_user_created
    # book_groups_user_member
    # comments_created


class GroupManager(models.Manager):
    def group_validator(self, postData):
        errors = {}
        
        if len(postData['location']) < 3:
            errors['location'] = "Your location must be at least 3 characters. Please try again."

        if len(postData['weekday']) < 1:
            errors['weekday'] = "Your weekday must be at least 1 characters."
        
        if len(postData['weekday']) < 1:
            errors['weekday'] = "Your weekday must be at least 1 characters."

        if len(postData['time']) < 1:
            errors['time'] = "Your time must be at least 1 characters."
        
        if len(postData['time']) < 1:
            errors['time'] = "Your time must be at least 1 characters."
        return errors

class BookGroup(models.Model):
    book_name = models.CharField(max_length=100)
    book_author = models.CharField(max_length=45)
    book_year = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    book_group_members = models.ManyToManyField(User, related_name="book_groups_user_member")
    book_group_creator = models.ForeignKey(User, related_name="book_groups_user_created", on_delete = models.CASCADE)
    objects = GroupManager()
    # book_comments

class Comment(models.Model):
    comment_content = models.CharField(max_length=400)
    which_book = models.ForeignKey(BookGroup, related_name="book_comments", on_delete = models.CASCADE)
    commentator = models.ForeignKey(User, related_name="comments_created", on_delete = models.CASCADE)

