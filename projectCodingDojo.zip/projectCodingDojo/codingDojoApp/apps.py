from django.apps import AppConfig


class CodingdojoappConfig(AppConfig):
    name = 'codingDojoApp'
